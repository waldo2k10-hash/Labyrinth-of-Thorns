# World and Non-Human Characters

[← Back to Rules outline](README.md)
