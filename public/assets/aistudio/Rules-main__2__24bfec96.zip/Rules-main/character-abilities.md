# Character-Specific Abilities

[← Back to Rules outline](README.md)
