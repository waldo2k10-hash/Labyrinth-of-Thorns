# Core Concept

[← Back to Rules outline](README.md)
