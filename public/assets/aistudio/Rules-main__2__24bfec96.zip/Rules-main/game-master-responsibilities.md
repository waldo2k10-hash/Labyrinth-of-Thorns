# Game Master Responsibilities

[← Back to Rules outline](README.md)
