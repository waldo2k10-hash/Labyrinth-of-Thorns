# Non-Sexual Energy Loss and XP Progression

[← Back to Rules outline](README.md)

An engine-approved energy drain can reduce XP and, at thresholds, a level. Describe
fatigue or a dimming aura without graphic detail. Level 0 ends the run.
