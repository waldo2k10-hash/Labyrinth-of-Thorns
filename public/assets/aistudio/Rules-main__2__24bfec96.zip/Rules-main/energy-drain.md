# Non-Sexual Energy-Drain Mechanics

[← Back to Rules outline](README.md)

Energy drain is a non-contact supernatural attack that removes stored XP through
game-engine mechanics. It is not intimacy, affection, or romance. The player keeps
control of all choices; the Game Master describes only the engine-approved result.
