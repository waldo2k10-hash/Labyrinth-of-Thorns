# Supernatural Pressure

[← Back to Rules outline](README.md)

Pressure represents distraction caused by an uncanny place or hostile magical
effect. It never changes the protagonist's decisions or removes player agency.
