# Random Encounter Generator

[← Back to Rules outline](README.md)
