# THE UNKNOWN — Rules

The Node game reads `game-rules.txt` and the six active modules listed below.
`server.mjs` inserts them into the Game Master prompt on each turn. The Python
Ollama prototype also reads `game-rules.txt` and the original NPC inspiration in
[possible-npc-reference.txt](possible-npc-reference.txt).

## Active modules

| Module | Covers |
| --- | --- |
| [00_core.txt](00_core.txt) | General-audience tone, player agency, and engine commands |
| [01_predation.txt](01_predation.txt) | Non-contact energy drain, XP, and Level 0 |
| [02_psyche.txt](02_psyche.txt) | Supernatural pressure, anxiety, and willpower |
| [03_npcs.txt](03_npcs.txt) | NPC behavior and species |
| [04_world.txt](04_world.txt) | Skills, items, and world zones |
| [05_sfw_boundaries.txt](05_sfw_boundaries.txt) | General-audience boundaries and player agency |

The family files are optional worldbuilding references and are not loaded by the Node game.
`01_energy_drain.txt` is an additional non-sexual mechanics reference; the active Node module is `01_predation.txt`.

Precedence: general-audience boundaries, engine state, core agency rules, then the
most specific worldbuilding module.

## Design outline

The `.md` files below are short topic notes for the SFW design and are not loaded by
the game engine:

- [Core Concept](core-concept.md)
- [Game Master Responsibilities](game-master-responsibilities.md)
- [Player Agency](player-agency.md)
- [Opening Scenario](opening-scenario.md)
- [World and Non-Human Characters](world-and-characters.md)
- [Character Personality](character-personality.md)
- [Energy Drain Mechanics](energy-drain.md)
- [Character-Specific Abilities](character-abilities.md)
- [Platonic Relationships](relationships.md)
- [Nemesis Influence and Alliances](nemeses-and-alliances.md)
- [Supernatural Pressure](supernatural-pressure.md)
- [Willpower System](willpower.md)
- [Inventory and Equipment](inventory.md)
- [Dynamic Choice System](choices.md)
- [Scenario Skill Check System](skill-checks.md)
- [Energy Drain and XP Progression](energy-progression.md)
- [NPC Level Transfer and Evolution](npc-progression.md)
- [Game Over and Special Endings](endings.md)
- [Random Encounter Generator](random-encounters.md)
