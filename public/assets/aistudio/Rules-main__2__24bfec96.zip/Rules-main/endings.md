# Game Over and Special Endings

[← Back to Rules outline](README.md)
