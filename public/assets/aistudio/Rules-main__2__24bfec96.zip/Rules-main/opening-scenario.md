# Opening Scenario

[← Back to Rules outline](README.md)
