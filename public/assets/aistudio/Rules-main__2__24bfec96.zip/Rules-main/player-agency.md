# Player Agency

[← Back to Rules outline](README.md)
