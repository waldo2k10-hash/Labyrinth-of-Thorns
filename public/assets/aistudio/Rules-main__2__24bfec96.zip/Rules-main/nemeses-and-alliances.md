# Nemesis Influence and Alliances

[← Back to Rules outline](README.md)
