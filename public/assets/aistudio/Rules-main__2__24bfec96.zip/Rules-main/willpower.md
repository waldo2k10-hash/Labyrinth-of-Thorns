# Willpower System

[← Back to Rules outline](README.md)
