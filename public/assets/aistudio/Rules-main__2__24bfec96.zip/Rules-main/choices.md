# Dynamic Choice System

[← Back to Rules outline](README.md)
