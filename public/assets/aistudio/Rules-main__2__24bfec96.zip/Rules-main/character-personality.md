# Character Personality

[← Back to Rules outline](README.md)
