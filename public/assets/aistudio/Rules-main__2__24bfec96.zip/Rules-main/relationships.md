# Platonic Relationship System

[← Back to Rules outline](README.md)
